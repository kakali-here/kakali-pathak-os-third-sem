#Soft Link

ln -s /Users/sumithere/Desktop/coding/os/softLink.c /Users/sumithere/Desktop/coding/os/softLink
